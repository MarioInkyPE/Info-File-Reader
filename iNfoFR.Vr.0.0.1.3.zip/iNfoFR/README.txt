iNfo File Reader (iNfoFR)
Created by LMTalk
(http://lmtalk.proboards.com/)
Programmed By Lukie D.
(lukedzamonja@hotmail.com)
Icon & Suggestions by TheHappyFaceKing
(https://www.youtube.com/channel/UCoMUPu-QXdGfZPiQX_1Pptg)

Version 0.0.1.3

Changes 0.0.1.3 (2/22/2016)
==============================
-Added Status Bar
-Made a seperate Save and Save As
-Ctrl+S saves your file
-Ctrl+O Opens a file
-Ctrl+Shift+S Saves As a file

Changes 0.0.1.2 (2/19/2016)
==============================
-Added Insert Item Button
-Fixed issue with pressing enter with search dialog.

Changes 0.0.1.1 (2/18/2016)
==============================
-Fixed Search Function not always being on top anymore
-Fixed some bugs
-Added a function for linked items (The properties that all lead to the same value)
-Updated Documentation

Changes 0.0.1.0 (2/16/2016)
==============================
-Added Search Function
-Please E-Mail me for any bugs you find

Changes 0.0.0.35 (2/15/2016)
==============================
-Working on Search Engine
-Fixed minor bug with canceling saving

Changes 0.0.0.3 (2/10/2016)
==============================
-Added an icon
-Made it so you don't need to install Visual Studio 2015 C++ runtime stuff. (comes in the program now :D)

Changes 0.0.0.2 (2/8/2016)
==============================
-Fixed some major bugs
-Added in a document system. (Document file is editable)

Changes 0.0.0.1 (2/7/2016)
==============================
-Made info files readable, as well as writable.
-Users can add and remove Entrys/Items.
-Floats, ints, and two sizes of strings are included.


==============================
Plans:
-Make a Taskbar at the bottom to display general info about the file
-Add warning messages for doing certain actions
-Add a Tabs function for multiple file viewing
-Add right-clicking options, and some keyboard shourtcuts
-Add an icon
-Delete and copy multiple Entrys/Items


